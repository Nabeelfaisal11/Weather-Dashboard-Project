// src/components/Controls.jsx
console.log("✅ Controls loaded");

export default function Controls() {
  return (
    <div style={{padding:12, border:"1px solid #334", borderRadius:8}}>
      Controls OK
    </div>
  );
}
